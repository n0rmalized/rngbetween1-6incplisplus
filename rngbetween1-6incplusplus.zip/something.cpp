#include <iostream>
#include <thread>
#include <chrono>

int main(){



    srand(time(NULL));

    int num = (rand() % 6)+ 1;

    std::cout << num;

    using namespace std::chrono_literals;
    std::this_thread::sleep_for(3s);

    return 0;
}